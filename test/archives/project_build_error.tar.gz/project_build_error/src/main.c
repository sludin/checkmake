#include <stdio.h>

int main( int argc, char** argv ) {
  xxprintf( "Checkmake is working\n" );
  return 0;
}
